<?php
session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";

$search = "";

if (isset($_GET["search"])) {
    $search = $_GET["search"];
}

$sql = "SELECT * FROM patients 
        WHERE name LIKE '%$search%'";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>

    <title>Search Patient</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: #1f4e79;
        }

        .search-box {
            text-align: center;
            margin: 30px;
        }

        input {
            width: 300px;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            padding: 12px 20px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            margin-top: 30px;
        }

        th {
            background-color: #1f4e79;
            color: white;
            padding: 12px;
        }

        td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .back {
            display: block;
            width: 180px;
            margin: 25px auto;
            padding: 12px;
            text-align: center;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>

</head>

<body>

<h1>🔍 Search Patient</h1>

<div class="search-box">

    <form method="GET">

        <input type="text"
               name="search"
               placeholder="Enter patient name"
               value="<?php echo $search; ?>">

        <button type="submit">Search</button>

    </form>

</div>

<table>

    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Gender</th>
        <th>Phone</th>
        <th>Disease</th>
    </tr>

<?php

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["age"] . "</td>";
        echo "<td>" . $row["gender"] . "</td>";
        echo "<td>" . $row["phone"] . "</td>";
        echo "<td>" . $row["disease"] . "</td>";
        echo "</tr>";
    }

} else {

    echo "<tr>";
    echo "<td colspan='6'>No patient found</td>";
    echo "</tr>";
}

?>

</table>

<a class="back" href="admin_dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>