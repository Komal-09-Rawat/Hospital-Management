<?php

session_start();

if (isset($_POST["login"])) {

    $username = $_POST["username"];
    $password = $_POST["password"];

    // Your Login Details
    if ($username == "Komal" && $password == "Komal@123") {

        $_SESSION["admin"] = $username;

        header("Location: admin_dashboard.php");
        exit();

    } else {

        $error = "Invalid username or password";

    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Admin Login - Hospital Management System</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
            padding: 0;
        }

        .login-box {
            width: 350px;
            margin: 100px auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px #ccc;
        }

        h1 {
            text-align: center;
            color: #1f4e79;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        input:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 25px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #163a5c;
        }

        .error {
            text-align: center;
            color: red;
            margin-top: 15px;
        }

        .info {
            text-align: center;
            color: #777;
            margin-top: 20px;
            font-size: 14px;
        }

    </style>

</head>

<body>

<div class="login-box">

    <h1>🏥 Admin Login</h1>

    <form method="POST">

        <label>Username:</label>

        <input
            type="text"
            name="username"
            placeholder="Enter username"
            required
        >


        <label>Password:</label>

        <input
            type="password"
            name="password"
            placeholder="Enter password"
            required
        >


        <button type="submit" name="login">
            🔐 Login
        </button>

    </form>


    <?php

    if (isset($error)) {

        echo "<p class='error'>$error</p>";

    }

    ?>


    <p style="text-align:center;"><a href="index.php">🏠 Back to Home</a></p>

<p class="info">
        Hospital Management System
    </p>

</div>

</body>

</html>