<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: user_login.php");
    exit();
}

$user_name = $_SESSION["user_name"];

?>

<!DOCTYPE html>
<html>

<head>

    <title>User Dashboard</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 40px auto;
        }

        .welcome {
            background-color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
            margin-bottom: 30px;
        }

        .welcome h2 {
            color: #1f4e79;
            margin-top: 0;
        }

        .welcome p {
            color: #666;
        }

        .cards {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
        }

        .card {
            background-color: white;
            width: 260px;
            padding: 30px 20px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
        }

        .card .icon {
            font-size: 40px;
        }

        .card h3 {
            color: #1f4e79;
        }

        .card p {
            color: #666;
        }

        .card a {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .card a:hover {
            background-color: #163a5c;
        }

        .footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: #777;
        }

    </style>

</head>

<body>

    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="index.php">🏠 Home</a>
            <a href="logout_user.php">
            Logout
        </a>

    </div>


    <div class="container">

        <div class="welcome">

            <h2>
                Welcome, <?php echo htmlspecialchars($user_name); ?> 👋
            </h2>

            <p>
                Manage your hospital appointments easily from your dashboard.
            </p>

        </div>


        <div class="cards">


            <!-- Book Appointment -->

            <div class="card">

                <div class="icon">📅</div>

                <h3>Book Appointment</h3>

                <p>
                    Book a new appointment with a doctor.
                </p>

                <a href="book_appointment.php">
                    Book Now
                </a>

            </div>


            <!-- My Appointments -->

            <div class="card">

                <div class="icon">📋</div>

                <h3>My Appointments</h3>

                <p>
                    View your appointment details and status.
                </p>

                <a href="my_appointments.php">
                    View Appointments
                </a>

            </div>


            <!-- Our Doctors -->

            <div class="card">

                <div class="icon">👨‍⚕️</div>

                <h3>Our Doctors</h3>

                <p>
                    View available doctors and their details.
                </p>

                <a href="user_doctors.php">
                    View Doctors
                </a>

            </div>


        </div>

    </div>


    <div class="footer">

        Hospital Management System

    </div>

</body>

</html>