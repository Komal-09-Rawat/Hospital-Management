<?php
session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}


include "db.php";

if (isset($_POST["submit"])) {

    $patient_name = $_POST["patient_name"];
    $doctor_name = $_POST["doctor_name"];
    $appointment_date = $_POST["appointment_date"];
    $appointment_time = $_POST["appointment_time"];
    $reason = $_POST["reason"];

    $sql = "INSERT INTO appointments
            (patients_name, doctor_name, appointment_date, appointment_time, reason)
            VALUES
            ('$patient_name', '$doctor_name', '$appointment_date', '$appointment_time', '$reason')";

    if ($conn->query($sql) === TRUE) {

        echo "<p class='success'>Appointment added successfully!</p>";

    } else {

        echo "<p class='error'>Error: " . $conn->error . "</p>";

    }
}


/* Get Patients */

$patients = $conn->query("SELECT * FROM patients");


/* Get Doctors */

$doctors = $conn->query("SELECT * FROM doctors");

?>

<!DOCTYPE html>
<html>

<head>

    <title>Add Appointment</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: #1f4e79;
        }

        form {
            width: 400px;
            margin: 30px auto;
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px #ccc;
        }

        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
        }

        select,
        input {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #163a5c;
        }

        .success {
            text-align: center;
            color: green;
            font-weight: bold;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
        }

        .back {
            display: block;
            width: 180px;
            margin: 20px auto;
            padding: 12px;
            text-align: center;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

    </style>

</head>


<body>


<h1>📅 Add New Appointment</h1>


<form method="POST">


    <!-- Patient -->

    <label>Patient Name:</label>

    <select name="patient_name" required>

        <option value="">Select Patient</option>

        <?php

        while ($patient = $patients->fetch_assoc()) {

            echo "<option value='" . $patient["name"] . "'>";
            echo $patient["name"];
            echo "</option>";

        }

        ?>

    </select>


    <!-- Doctor -->

    <label>Doctor Name:</label>

    <select name="doctor_name" required>

        <option value="">Select Doctor</option>

        <?php

        while ($doctor = $doctors->fetch_assoc()) {

            echo "<option value='" . $doctor["name"] . "'>";
            echo $doctor["name"] . " - " . $doctor["specialization"];
            echo "</option>";

        }

        ?>

    </select>


    <!-- Date -->

    <label>Appointment Date:</label>

    <input
        type="date"
        name="appointment_date"
        required
    >


    <!-- Time -->

    <label>Appointment Time:</label>

    <input
        type="time"
        name="appointment_time"
        required
    >


    <!-- Reason -->

    <label>Reason:</label>

    <input
        type="text"
        name="reason"
        placeholder="Enter reason"
        required
    >


    <button type="submit" name="submit">
        Add Appointment
    </button>


</form>


<a class="back" href="admin_dashboard.php">
    ⬅ Back to Dashboard
</a>


</body>

</html>