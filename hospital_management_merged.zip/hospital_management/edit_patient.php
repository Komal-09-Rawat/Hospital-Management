<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";


/* Check Patient ID */

if (!isset($_GET["id"])) {
    die("Patient ID not found");
}

$id = $_GET["id"];


/* Get Patient */

$sql = "SELECT * FROM patients WHERE id=$id";

$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    die("Patient not found");
}

$patient = $result->fetch_assoc();


/* Update Patient */

if (isset($_POST["update"])) {

    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $phone = $_POST["phone"];
    $disease = $_POST["disease"];

    $sql = "UPDATE patients SET
            name='$name',
            age='$age',
            gender='$gender',
            phone='$phone',
            disease='$disease'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {

        header("Location: patients.php");
        exit();

    } else {

        $error = "Error: " . $conn->error;

    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Edit Patient</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background-color: #c9302c;
        }

        .container {
            width: 90%;
            max-width: 500px;
            margin: 40px auto;
        }

        .form-box {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px #ddd;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-top: 0;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #163a5c;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        .buttons {
            text-align: center;
            margin-top: 25px;
        }

        .buttons a {
            display: inline-block;
            padding: 11px 18px;
            margin: 5px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 7px;
        }

        .buttons a:hover {
            background-color: #163a5c;
        }

    </style>

</head>

<body>


    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="logout.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <div class="container">

        <div class="form-box">

            <h2>✏️ Edit Patient</h2>

            <p class="subtitle">
                Update patient information
            </p>


            <form method="POST">


                <label>Patient Name:</label>

                <input
                    type="text"
                    name="name"
                    value="<?php echo htmlspecialchars($patient['name']); ?>"
                    required
                >


                <label>Age:</label>

                <input
                    type="number"
                    name="age"
                    value="<?php echo htmlspecialchars($patient['age']); ?>"
                    min="1"
                    max="120"
                    required
                >


                <label>Gender:</label>

                <select name="gender" required>

                    <option value="Male"
                        <?php
                        if ($patient['gender'] == 'Male')
                            echo 'selected';
                        ?>>
                        Male
                    </option>

                    <option value="Female"
                        <?php
                        if ($patient['gender'] == 'Female')
                            echo 'selected';
                        ?>>
                        Female
                    </option>

                    <option value="Other"
                        <?php
                        if ($patient['gender'] == 'Other')
                            echo 'selected';
                        ?>>
                        Other
                    </option>

                </select>


                <label>Phone:</label>

                <input
                    type="text"
                    name="phone"
                    value="<?php echo htmlspecialchars($patient['phone']); ?>"
                    required
                >


                <label>Disease:</label>

                <input
                    type="text"
                    name="disease"
                    value="<?php echo htmlspecialchars($patient['disease']); ?>"
                    required
                >


                <button type="submit" name="update">
                    💾 Update Patient
                </button>

            </form>


            <?php

            if (isset($error)) {

                echo "<p class='error'>$error</p>";

            }

            ?>


            <div class="buttons">

                <a href="patients.php">
                    👤 Back to Patients
                </a>

                <a href="admin_dashboard.php">
                    ⬅ Dashboard
                </a>

            </div>

        </div>

    </div>

</body>

</html>