HOSPITAL MANAGEMENT SYSTEM - MERGED VERSION

Main URL:
http://localhost/hospital_management/

Flow:
1. Main page (index.php)
   - Admin Login
   - User Login
   - User Registration

2. Admin:
   login.php -> admin_dashboard.php
   Admin dashboard -> Patients / Doctors / Appointments
   Admin logout -> login.php

3. User:
   register.php -> user_login.php
   user_login.php -> user_dashboard.php
   User dashboard -> Book Appointment / My Appointments / Our Doctors
   User logout -> user_login.php

Important:
- Existing database configuration in db.php was not changed.
- Existing data was not changed.
- Existing Admin dashboard was renamed from index.php to admin_dashboard.php so index.php can be the common starting page.
