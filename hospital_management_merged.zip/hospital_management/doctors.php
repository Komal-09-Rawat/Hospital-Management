<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";

/* Delete Doctor */

if (isset($_GET["delete"])) {

    $id = $_GET["delete"];

    $sql = "DELETE FROM doctors WHERE id=$id";

    if ($conn->query($sql) === TRUE) {

        header("Location: doctors.php");
        exit();

    } else {

        echo "Error: " . $conn->error;

    }
}


/* Get Doctors */

$sql = "SELECT * FROM doctors";

$result = $conn->query($sql);

if (!$result) {

    die("Error: " . $conn->error);

}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Manage Doctors</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        /* Header */

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background-color: #c9302c;
        }

        /* Container */

        .container {
            width: 95%;
            max-width: 1200px;
            margin: 40px auto;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }

        /* Table */

        .table-box {
            background-color: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #ddd;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        th {
            background-color: #1f4e79;
            color: white;
            padding: 14px;
        }

        td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Action Buttons */

        .action a {
            display: inline-block;
            padding: 8px 12px;
            margin: 3px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 13px;
        }

        .edit {
            background-color: #f0ad4e;
        }

        .edit:hover {
            background-color: #ec971f;
        }

        .delete {
            background-color: #d9534f;
        }

        .delete:hover {
            background-color: #c9302c;
        }

        /* Bottom Buttons */

        .buttons {
            text-align: center;
            margin-top: 30px;
        }

        .buttons a {
            display: inline-block;
            padding: 12px 20px;
            margin: 5px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

        .buttons a:hover {
            background-color: #163a5c;
        }

        .add {
            background-color: #28a745 !important;
        }

        .add:hover {
            background-color: #218838 !important;
        }

        .search {
            background-color: #5cb85c !important;
        }

        .search:hover {
            background-color: #449d44 !important;
        }

        .no-data {
            text-align: center;
            color: #777;
            padding: 30px;
        }

    </style>

</head>

<body>


    <!-- Header -->

    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="logout.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <!-- Main -->

    <div class="container">

        <h2>👨‍⚕️ Manage Doctors</h2>

        <p class="subtitle">
            View and manage all hospital doctors
        </p>


        <div class="table-box">

            <?php

            if ($result->num_rows > 0) {

            ?>

                <table>

                    <tr>

                        <th>ID</th>
                        <th>Doctor Name</th>
                        <th>Specialization</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Action</th>

                    </tr>


                    <?php

                    while ($row = $result->fetch_assoc()) {

                        echo "<tr>";

                        echo "<td>" .
                             $row["id"] .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["name"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["specialization"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["phone"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["email"]) .
                             "</td>";


                        echo "<td class='action'>";

                        echo "<a class='edit'
                                href='edit_doctor.php?id=" .
                                $row["id"] . "'>
                                ✏️ Edit
                              </a>";


                        echo "<a class='delete'
                                href='doctors.php?delete=" .
                                $row["id"] . "'
                                onclick=\"return confirm('Are you sure you want to delete this doctor?')\">
                                🗑️ Delete
                              </a>";

                        echo "</td>";

                        echo "</tr>";

                    }

                    ?>

                </table>


            <?php

            } else {

                echo "<div class='no-data'>";

                echo "👨‍⚕️ No doctors found.";

                echo "</div>";

            }

            ?>

        </div>


        <!-- Buttons -->

        <div class="buttons">

            <a href="add_doctor.php" class="add">
                ➕ Add Doctor
            </a>

            <a href="search_doctor.php" class="search">
                🔍 Search Doctor
            </a>

            <a href="admin_dashboard.php">
                ⬅ Back to Dashboard
            </a>

        </div>


    </div>

</body>

</html>