<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: user_login.php");
    exit();
}

include "db.php";

$sql = "SELECT * FROM doctors";
$result = $conn->query($sql);

if (!$result) {
    die("Error: " . $conn->error);
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Our Doctors</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background-color: #c9302c;
        }

        .container {
            width: 95%;
            max-width: 1100px;
            margin: 40px auto;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-bottom: 10px;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }

        .table-box {
            background-color: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #ddd;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 750px;
        }

        th {
            background-color: #1f4e79;
            color: white;
            padding: 14px;
        }

        td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .no-data {
            text-align: center;
            color: #777;
            padding: 30px;
        }

        .buttons {
            text-align: center;
            margin-top: 30px;
        }

        .buttons a {
            display: inline-block;
            padding: 12px 20px;
            margin: 5px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

        .buttons a:hover {
            background-color: #163a5c;
        }

    </style>

</head>

<body>


    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="logout_user.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <div class="container">

        <h2>👨‍⚕️ Our Doctors</h2>

        <p class="subtitle">
            View available doctors and their specializations
        </p>


        <div class="table-box">

            <?php

            if ($result->num_rows > 0) {

            ?>

                <table>

                    <tr>

                        <th>Doctor Name</th>
                        <th>Specialization</th>
                        <th>Phone</th>
                        <th>Email</th>

                    </tr>


                    <?php

                    while ($doctor = $result->fetch_assoc()) {

                        echo "<tr>";

                        echo "<td>" .
                             htmlspecialchars($doctor["name"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($doctor["specialization"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($doctor["phone"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($doctor["email"]) .
                             "</td>";

                        echo "</tr>";

                    }

                    ?>

                </table>


            <?php

            } else {

                echo "<div class='no-data'>";

                echo "👨‍⚕️ No doctors available.";

                echo "</div>";

            }

            ?>

        </div>


        <div class="buttons">

            <a href="user_dashboard.php">
                ⬅ Back to Dashboard
            </a>

            <a href="book_appointment.php">
                📅 Book Appointment
            </a>

        </div>

    </div>

</body>

</html>