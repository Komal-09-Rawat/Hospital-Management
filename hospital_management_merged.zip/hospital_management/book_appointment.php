<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: user_login.php");
    exit();
}

include "db.php";

$user_name = $_SESSION["user_name"];

$doctors = $conn->query("SELECT * FROM doctors");

if (isset($_POST["book"])) {

    $doctor_name = $_POST["doctor_name"];
    $appointment_date = $_POST["appointment_date"];
    $appointment_time = $_POST["appointment_time"];
    $reason = $_POST["reason"];

    $sql = "INSERT INTO appointments
            (patients_name, doctor_name, appointment_date, appointment_time, reason)
            VALUES
            ('$user_name', '$doctor_name', '$appointment_date',
             '$appointment_time', '$reason')";

    if ($conn->query($sql) === TRUE) {

        $success = "Appointment booked successfully!";

    } else {

        $error = "Error: " . $conn->error;

    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Book Appointment</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background-color: #c9302c;
        }

        .container {
            width: 90%;
            max-width: 550px;
            margin: 40px auto;
        }

        .appointment-box {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px #ddd;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-top: 0;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #1f4e79;
        }

        input[readonly] {
            background-color: #f1f1f1;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #163a5c;
        }

        .success {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-top: 20px;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        .buttons {
            text-align: center;
            margin-top: 25px;
        }

        .buttons a {
            display: inline-block;
            padding: 11px 18px;
            margin: 5px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 7px;
        }

        .buttons a:hover {
            background-color: #163a5c;
        }

        .appointments {
            background-color: #5cb85c !important;
        }

        .appointments:hover {
            background-color: #449d44 !important;
        }

    </style>

</head>

<body>


    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="logout_user.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <div class="container">

        <div class="appointment-box">

            <h2>📅 Book Appointment</h2>

            <p class="subtitle">
                Welcome, <?php echo htmlspecialchars($user_name); ?> 👋
            </p>


            <form method="POST">


                <label>Patient Name:</label>

                <input
                    type="text"
                    value="<?php echo htmlspecialchars($user_name); ?>"
                    readonly
                >


                <label>Select Doctor:</label>

                <select name="doctor_name" required>

                    <option value="">
                        Select Doctor
                    </option>

                    <?php

                    if ($doctors->num_rows > 0) {

                        while ($doctor = $doctors->fetch_assoc()) {

                            echo "<option value='" .
                                 htmlspecialchars($doctor["name"]) .
                                 "'>";

                            echo htmlspecialchars($doctor["name"]) .
                                 " - " .
                                 htmlspecialchars($doctor["specialization"]);

                            echo "</option>";

                        }

                    }

                    ?>

                </select>


                <label>Appointment Date:</label>

                <input
                    type="date"
                    name="appointment_date"
                    required
                >


                <label>Appointment Time:</label>

                <input
                    type="time"
                    name="appointment_time"
                    required
                >


                <label>Reason:</label>

                <input
                    type="text"
                    name="reason"
                    placeholder="Enter reason for appointment"
                    required
                >


                <button type="submit" name="book">
                    📅 Book Appointment
                </button>

            </form>


            <?php

            if (isset($success)) {

                echo "<p class='success'>$success</p>";

            }

            if (isset($error)) {

                echo "<p class='error'>$error</p>";

            }

            ?>


            <div class="buttons">

                <a href="my_appointments.php"
                   class="appointments">
                    📋 My Appointments
                </a>

                <a href="user_dashboard.php">
                    ⬅ Dashboard
                </a>

            </div>

        </div>

    </div>

</body>

</html>