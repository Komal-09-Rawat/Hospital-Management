<?php
session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";

if (!isset($_GET["id"])) {
    die("Appointment ID not found");
}

$id = $_GET["id"];

$sql = "SELECT * FROM appointments WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Appointment not found");
}

$appointment = $result->fetch_assoc();

if (isset($_POST["update"])) {

    $patient_name = $_POST["patient_name"];
    $doctor_name = $_POST["doctor_name"];
    $appointment_date = $_POST["appointment_date"];
    $appointment_time = $_POST["appointment_time"];
    $reason = $_POST["reason"];

    $sql = "UPDATE appointments SET
            patients_name = '$patient_name',
            doctor_name = '$doctor_name',
            appointment_date = '$appointment_date',
            appointment_time = '$appointment_time',
            reason = '$reason'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: appointments.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>

    <title>Edit Appointment</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: #1f4e79;
        }

        form {
            width: 400px;
            margin: 30px auto;
            background-color: white;
            padding: 25px;
            border-radius: 10px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .back {
            display: block;
            width: 180px;
            margin: 20px auto;
            padding: 12px;
            text-align: center;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>

</head>

<body>

<h1>✏️ Edit Appointment</h1>

<form method="POST">

    <label>Patient Name:</label>
    <input type="text" name="patient_name"
           value="<?php echo $appointment['patients_name']; ?>" required>

    <label>Doctor Name:</label>
    <input type="text" name="doctor_name"
           value="<?php echo $appointment['doctor_name']; ?>" required>

    <label>Appointment Date:</label>
    <input type="date" name="appointment_date"
           value="<?php echo $appointment['appointment_date']; ?>" required>

    <label>Appointment Time:</label>
    <input type="time" name="appointment_time"
           value="<?php echo $appointment['appointment_time']; ?>" required>

    <label>Reason:</label>
    <input type="text" name="reason"
           value="<?php echo $appointment['reason']; ?>" required>

    <button type="submit" name="update">Update Appointment</button>

</form>

<a class="back" href="appointments.php">⬅ Back to Appointments</a>

</body>
</html>