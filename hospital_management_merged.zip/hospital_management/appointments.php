<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";

/* Approve appointment */
if (isset($_GET["approve"])) {

    $id = $_GET["approve"];

    $sql = "UPDATE appointments
            SET status='Approved'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: appointments.php");
        exit();
    }
}

/* Cancel appointment */
if (isset($_GET["cancel"])) {

    $id = $_GET["cancel"];

    $sql = "UPDATE appointments
            SET status='Cancelled'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: appointments.php");
        exit();
    }
}

/* Delete appointment */
if (isset($_GET["delete"])) {

    $id = $_GET["delete"];

    $sql = "DELETE FROM appointments
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: appointments.php");
        exit();
    }
}

/* Get appointments */
$sql = "SELECT * FROM appointments
        ORDER BY appointment_date, appointment_time";

$result = $conn->query($sql);

if (!$result) {
    die("Error: " . $conn->error);
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Manage Appointments</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        /* Header */

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background-color: #c9302c;
        }

        /* Main */

        .container {
            width: 95%;
            max-width: 1200px;
            margin: 40px auto;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }

        /* Table */

        .table-box {
            background-color: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #ddd;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        th {
            background-color: #1f4e79;
            color: white;
            padding: 14px;
        }

        td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        /* Status */

        .pending {
            color: #f0ad4e;
            font-weight: bold;
        }

        .approved {
            color: green;
            font-weight: bold;
        }

        .cancelled {
            color: red;
            font-weight: bold;
        }

        /* Buttons */

        .action a {
            display: inline-block;
            padding: 8px 10px;
            margin: 3px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 13px;
        }

        .approve {
            background-color: #28a745;
        }

        .approve:hover {
            background-color: #218838;
        }

        .cancel {
            background-color: #f0ad4e;
        }

        .cancel:hover {
            background-color: #ec971f;
        }

        .delete {
            background-color: #d9534f;
        }

        .delete:hover {
            background-color: #c9302c;
        }

        /* Bottom buttons */

        .bottom-buttons {
            text-align: center;
            margin-top: 30px;
        }

        .bottom-buttons a {
            display: inline-block;
            padding: 12px 20px;
            margin: 5px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

        .bottom-buttons a:hover {
            background-color: #163a5c;
        }

        .no-data {
            text-align: center;
            color: #777;
            padding: 30px;
        }

    </style>

</head>

<body>


    <!-- Header -->

    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="logout.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <!-- Main -->

    <div class="container">

        <h2>📅 Manage Appointments</h2>

        <p class="subtitle">
            View and manage all patient appointments
        </p>


        <div class="table-box">

            <?php

            if ($result->num_rows > 0) {

            ?>

                <table>

                    <tr>

                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Action</th>

                    </tr>


                    <?php

                    while ($row = $result->fetch_assoc()) {

                        echo "<tr>";

                        echo "<td>" .
                             $row["id"] .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["patients_name"]) .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["doctor_name"]) .
                             "</td>";

                        echo "<td>" .
                             $row["appointment_date"] .
                             "</td>";

                        echo "<td>" .
                             $row["appointment_time"] .
                             "</td>";

                        echo "<td>" .
                             htmlspecialchars($row["reason"]) .
                             "</td>";


                        /* Status */

                        if ($row["status"] == "Approved") {

                            echo "<td class='approved'>
                                  ✅ Approved
                                  </td>";

                        } elseif ($row["status"] == "Cancelled") {

                            echo "<td class='cancelled'>
                                  ❌ Cancelled
                                  </td>";

                        } else {

                            echo "<td class='pending'>
                                  🟠 Pending
                                  </td>";
                        }


                        /* Actions */

                        echo "<td class='action'>";


                        if ($row["status"] != "Approved") {

                            echo "<a class='approve'
                                    href='appointments.php?approve=" .
                                    $row["id"] . "'
                                    onclick=\"return confirm('Approve this appointment?')\">
                                    Approve
                                  </a>";
                        }


                        if ($row["status"] != "Cancelled") {

                            echo "<a class='cancel'
                                    href='appointments.php?cancel=" .
                                    $row["id"] . "'
                                    onclick=\"return confirm('Cancel this appointment?')\">
                                    Cancel
                                  </a>";
                        }


                        echo "<a class='delete'
                                href='appointments.php?delete=" .
                                $row["id"] . "'
                                onclick=\"return confirm('Delete this appointment?')\">
                                Delete
                              </a>";


                        echo "</td>";

                        echo "</tr>";

                    }

                    ?>

                </table>


            <?php

            } else {

                echo "<div class='no-data'>";
                echo "📋 No appointments found.";
                echo "</div>";

            }

            ?>

        </div>


        <div class="bottom-buttons">

            <a href="admin_dashboard.php">
                ⬅ Back to Dashboard
            </a>

            <a href="add_appointment.php">
                ➕ Add Appointment
            </a>

        </div>


    </div>

</body>

</html>