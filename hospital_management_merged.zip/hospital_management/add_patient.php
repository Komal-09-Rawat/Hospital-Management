<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";

if (isset($_POST["submit"])) {

    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $phone = $_POST["phone"];
    $disease = $_POST["disease"];

    $sql = "INSERT INTO patients
            (name, age, gender, phone, disease)
            VALUES
            ('$name', '$age', '$gender', '$phone', '$disease')";

    if ($conn->query($sql) === TRUE) {

        $success = "Patient added successfully!";

    } else {

        $error = "Error: " . $conn->error;

    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Add Patient</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .container {
            width: 90%;
            max-width: 500px;
            margin: 40px auto;
        }

        .form-box {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px #ddd;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #163a5c;
        }

        .success {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-top: 20px;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        .buttons {
            text-align: center;
            margin-top: 25px;
        }

        .buttons a {
            display: inline-block;
            padding: 11px 18px;
            margin: 5px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 7px;
        }

        .buttons a:hover {
            background-color: #163a5c;
        }

    </style>

</head>

<body>

    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="logout.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <div class="container">

        <div class="form-box">

            <h2>➕ Add New Patient</h2>

            <form method="POST">

                <label>Patient Name:</label>

                <input
                    type="text"
                    name="name"
                    placeholder="Enter patient name"
                    required
                >


                <label>Age:</label>

                <input
                    type="number"
                    name="age"
                    placeholder="Enter age"
                    min="1"
                    max="120"
                    required
                >


                <label>Gender:</label>

                <select name="gender" required>

                    <option value="">
                        Select Gender
                    </option>

                    <option value="Male">
                        Male
                    </option>

                    <option value="Female">
                        Female
                    </option>

                    <option value="Other">
                        Other
                    </option>

                </select>


                <label>Phone:</label>

                <input
                    type="text"
                    name="phone"
                    placeholder="Enter phone number"
                    required
                >


                <label>Disease:</label>

                <input
                    type="text"
                    name="disease"
                    placeholder="Enter disease"
                    required
                >


                <button type="submit" name="submit">
                    ➕ Add Patient
                </button>

            </form>


            <?php

            if (isset($success)) {

                echo "<p class='success'>$success</p>";

            }

            if (isset($error)) {

                echo "<p class='error'>$error</p>";

            }

            ?>


            <div class="buttons">

                <a href="patients.php">
                    👤 View Patients
                </a>

                <a href="admin_dashboard.php">
                    ⬅ Dashboard
                </a>

            </div>

        </div>

    </div>

</body>

</html>