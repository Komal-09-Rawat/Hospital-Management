<?php

session_start();

if (isset($_SESSION["user_id"])) {
    header("Location: user_dashboard.php");
    exit();
}

include "db.php";

if (isset($_POST["login"])) {

    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email='$email'";

    $result = $conn->query($sql);

    if ($result->num_rows == 1) {

        $user = $result->fetch_assoc();

        if (password_verify($password, $user["password"])) {

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["user_name"] = $user["name"];

            header("Location: user_dashboard.php");
            exit();

        } elseif ($password === $user["password"]) {

            $new_password = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $update = "UPDATE users
                       SET password='$new_password'
                       WHERE id=" . $user["id"];

            $conn->query($update);

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["user_name"] = $user["name"];

            header("Location: user_dashboard.php");
            exit();

        } else {

            $error = "Invalid password!";

        }

    } else {

        $error = "Email not registered!";

    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>User Login</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .container {
            width: 90%;
            max-width: 450px;
            margin: 60px auto;
        }

        .login-box {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px #ddd;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-top: 0;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #163a5c;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        .register {
            text-align: center;
            margin-top: 25px;
            color: #555;
        }

        .register a {
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

        .register a:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body>


    <div class="header">

        <h1>🏥 Hospital Management System</h1>

    </div>


    <div class="container">

        <div class="login-box">

            <h2>🔐 User Login</h2>

            <p class="subtitle">
                Login to manage your hospital appointments
            </p>


            <form method="POST">


                <label>Email:</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Enter your email"
                    required
                >


                <label>Password:</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >


                <button type="submit" name="login">
                    🔐 Login
                </button>

            </form>


            <?php

            if (isset($error)) {

                echo "<p class='error'>$error</p>";

            }

            ?>


            <div class="register">

                New user?

                <p style="text-align:center;"><a href="index.php">🏠 Back to Home</a></p>

<a href="register.php">
                    Create an account
                </a>

            </div>

        </div>

    </div>

</body>

</html>