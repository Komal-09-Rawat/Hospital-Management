<?php

session_start();

if (isset($_SESSION["user_id"])) {
    header("Location: user_dashboard.php");
    exit();
}

include "db.php";

if (isset($_POST["register"])) {

    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    $check = $conn->query(
        "SELECT * FROM users WHERE email='$email'"
    );

    if ($check->num_rows > 0) {

        $error = "Email already registered!";

    } else {

        $hashed_password = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $sql = "INSERT INTO users
                (name, phone, email, password)
                VALUES
                ('$name', '$phone', '$email', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {

            header("Location: user_login.php");
            exit();

        } else {

            $error = "Registration failed!";

        }
    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>User Registration</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .container {
            width: 90%;
            max-width: 450px;
            margin: 45px auto;
        }

        .register-box {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 15px #ddd;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-top: 0;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #163a5c;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
            margin-top: 20px;
        }

        .login {
            text-align: center;
            margin-top: 25px;
            color: #555;
        }

        .login a {
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

        .login a:hover {
            text-decoration: underline;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 18px;
            color: #555;
            text-decoration: none;
        }

    </style>

</head>

<body>


    <div class="header">

        <h1>🏥 Hospital Management System</h1>

    </div>


    <div class="container">

        <div class="register-box">

            <h2>📝 Create Account</h2>

            <p class="subtitle">
                Register to book hospital appointments
            </p>


            <form method="POST">


                <label>Name:</label>

                <input
                    type="text"
                    name="name"
                    placeholder="Enter your name"
                    required
                >


                <label>Phone:</label>

                <input
                    type="text"
                    name="phone"
                    placeholder="Enter phone number"
                    required
                >


                <label>Email:</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Enter email address"
                    required
                >


                <label>Password:</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Create a password"
                    required
                >


                <button type="submit" name="register">
                    📝 Register
                </button>

            </form>


            <?php

            if (isset($error)) {

                echo "<p class='error'>$error</p>";

            }

            ?>


            <div class="login">

                Already have an account?

                <a href="user_login.php">
                    Login here
                </a>

            </div>


            <a class="back" href="user_login.php">
                ⬅ Back to Login
            </a>

        </div>

    </div>

</body>

</html>