<?php

session_start();
include "db.php";

// Check user login
if (!isset($_SESSION["user_id"])) {
    header("Location: user_login.php");
    exit();
}

$user_name = $_SESSION["user_name"];

// Get this user's appointments
$sql = "SELECT * FROM appointments
        WHERE patients_name = '$user_name'
        ORDER BY appointment_date, appointment_time";

$result = $conn->query($sql);

if (!$result) {
    die("Error: " . $conn->error);
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>My Appointments</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: #1f4e79;
        }

        .welcome {
            text-align: center;
            color: #555;
            font-size: 17px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            margin-top: 30px;
        }

        th {
            background-color: #1f4e79;
            color: white;
            padding: 12px;
        }

        td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .pending {
            color: #f0ad4e;
            font-weight: bold;
        }

        .approved {
            color: green;
            font-weight: bold;
        }

        .cancelled {
            color: red;
            font-weight: bold;
        }

        .back {
            display: block;
            width: 180px;
            margin: 25px auto;
            padding: 12px;
            text-align: center;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

    </style>

</head>

<body>

<h1>📅 My Appointments</h1>

<p class="welcome">
    Welcome, <?php echo htmlspecialchars($user_name); ?> 👋
</p>

<table>

    <tr>

        <th>ID</th>
        <th>Doctor Name</th>
        <th>Date</th>
        <th>Time</th>
        <th>Reason</th>
        <th>Status</th>

    </tr>

<?php

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        echo "<tr>";

        echo "<td>" . $row["id"] . "</td>";

        echo "<td>" . htmlspecialchars($row["doctor_name"]) . "</td>";

        echo "<td>" . $row["appointment_date"] . "</td>";

        echo "<td>" . $row["appointment_time"] . "</td>";

        echo "<td>" . htmlspecialchars($row["reason"]) . "</td>";

        if ($row["status"] == "Approved") {

            echo "<td class='approved'>Approved</td>";

        } elseif ($row["status"] == "Cancelled") {

            echo "<td class='cancelled'>Cancelled</td>";

        } else {

            echo "<td class='pending'>Pending</td>";
        }

        echo "</tr>";
    }

} else {

    echo "<tr>";
    echo "<td colspan='6'>No appointments found</td>";
    echo "</tr>";
}

?>

</table>

<a class="back" href="book_appointment.php">
    ➕ Book New Appointment
</a>

</body>

</html>