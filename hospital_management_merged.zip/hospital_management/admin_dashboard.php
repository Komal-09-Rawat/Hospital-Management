<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "db.php";

// Count patients
$patient_count = $conn->query(
    "SELECT COUNT(*) AS total FROM patients"
)->fetch_assoc()["total"];

// Count doctors
$doctor_count = $conn->query(
    "SELECT COUNT(*) AS total FROM doctors"
)->fetch_assoc()["total"];

// Count appointments
$appointment_count = $conn->query(
    "SELECT COUNT(*) AS total FROM appointments"
)->fetch_assoc()["total"];

?>

<!DOCTYPE html>
<html>

<head>

    <title>Admin Dashboard</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            margin: 0;
        }

        /* Header */

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .logout {
            background-color: #d9534f;
            color: white;
            padding: 10px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background-color: #c9302c;
        }

        /* Main */

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
        }

        .welcome {
            background-color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
            margin-bottom: 30px;
        }

        .welcome h2 {
            color: #1f4e79;
            margin-top: 0;
        }

        .welcome p {
            color: #666;
        }

        /* Statistics */

        .stats {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
            margin-bottom: 40px;
        }

        .stat-card {
            background-color: white;
            width: 250px;
            padding: 25px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
        }

        .stat-card .icon {
            font-size: 40px;
        }

        .stat-card h2 {
            color: #1f4e79;
            font-size: 35px;
            margin: 10px 0;
        }

        .stat-card p {
            color: #555;
            font-size: 17px;
            font-weight: bold;
        }

        /* Management */

        .section-title {
            text-align: center;
            color: #1f4e79;
            margin-bottom: 25px;
        }

        .cards {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
        }

        .card {
            background-color: white;
            width: 260px;
            padding: 25px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
        }

        .card .icon {
            font-size: 40px;
        }

        .card h3 {
            color: #1f4e79;
        }

        .card p {
            color: #666;
            min-height: 40px;
        }

        .card a {
            display: inline-block;
            margin: 5px;
            padding: 10px 15px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .card a:hover {
            background-color: #163a5c;
        }

        .search {
            background-color: #5cb85c !important;
        }

        .search:hover {
            background-color: #449d44 !important;
        }

        /* Footer */

        .footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: #777;
        }

    </style>

</head>

<body>


    <!-- Header -->

    <div class="header">

        <h1>🏥 Hospital Management System</h1>

        <a href="index.php" class="home">🏠 Home</a>
            <a href="logout.php" class="logout">
            🚪 Logout
        </a>

    </div>


    <!-- Main Container -->

    <div class="container">


        <!-- Welcome -->

        <div class="welcome">

            <h2>
                Welcome, <?php echo htmlspecialchars($_SESSION["admin"]); ?> 👋
            </h2>

            <p>
                Manage patients, doctors and appointments from the admin dashboard.
            </p>

        </div>


        <!-- Statistics -->

        <div class="stats">


            <div class="stat-card">

                <div class="icon">👤</div>

                <h2>
                    <?php echo $patient_count; ?>
                </h2>

                <p>
                    Total Patients
                </p>

            </div>


            <div class="stat-card">

                <div class="icon">👨‍⚕️</div>

                <h2>
                    <?php echo $doctor_count; ?>
                </h2>

                <p>
                    Total Doctors
                </p>

            </div>


            <div class="stat-card">

                <div class="icon">📅</div>

                <h2>
                    <?php echo $appointment_count; ?>
                </h2>

                <p>
                    Total Appointments
                </p>

            </div>


        </div>


        <!-- Management -->

        <h2 class="section-title">
            ⚙️ Management
        </h2>


        <div class="cards">


            <!-- Patients -->

            <div class="card">

                <div class="icon">👤</div>

                <h3>Patients</h3>

                <p>
                    Add, view, edit and delete patients.
                </p>

                <a href="patients.php">
                    View Patients
                </a>

                <a href="add_patient.php">
                    Add Patient
                </a>

                <a href="search_patient.php" class="search">
                    Search
                </a>

            </div>


            <!-- Doctors -->

            <div class="card">

                <div class="icon">👨‍⚕️</div>

                <h3>Doctors</h3>

                <p>
                    Add, view, edit and delete doctors.
                </p>

                <a href="doctors.php">
                    View Doctors
                </a>

                <a href="add_doctor.php">
                    Add Doctor
                </a>

                <a href="search_doctor.php" class="search">
                    Search
                </a>

            </div>


            <!-- Appointments -->

            <div class="card">

                <div class="icon">📅</div>

                <h3>Appointments</h3>

                <p>
                    Manage and update patient appointments.
                </p>

                <a href="appointments.php">
                    View Appointments
                </a>

                <a href="add_appointment.php">
                    Add Appointment
                </a>

            </div>


        </div>


    </div>


    <!-- Footer -->

    <div class="footer">

        Hospital Management System | Admin Panel

    </div>


</body>

</html>