<!DOCTYPE html>
<html>
<head>
    <title>Hospital Management System</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fb;
            margin: 0;
            min-height: 100vh;
        }
        .header {
            background: #1f4e79;
            color: white;
            padding: 24px 40px;
            text-align: center;
        }
        .header h1 { margin: 0 0 8px; }
        .header p { margin: 0; }
        .container {
            max-width: 950px;
            margin: 55px auto;
            padding: 0 20px;
        }
        .welcome {
            text-align: center;
            margin-bottom: 35px;
        }
        .welcome h2 { color: #1f4e79; }
        .cards {
            display: grid;
            grid-template-columns: repeat(2, minmax(260px, 1fr));
            gap: 25px;
        }
        .card {
            background: white;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 3px 15px #ccc;
            text-align: center;
        }
        .icon { font-size: 45px; }
        .card h3 { color: #1f4e79; font-size: 24px; }
        .card p { color: #555; line-height: 1.5; }
        .btn {
            display: inline-block;
            width: 80%;
            margin: 8px 0;
            padding: 12px;
            border-radius: 8px;
            text-decoration: none;
            background: #1f4e79;
            color: white;
        }
        .btn.secondary { background: #5b8db8; }
        .btn:hover { opacity: .9; }
        .footer {
            text-align: center;
            color: #777;
            padding: 25px;
        }
        @media (max-width: 700px) {
            .cards { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>🏥 Hospital Management System</h1>
    <p>Welcome to the Hospital Management Portal</p>
</div>

<div class="container">
    <div class="welcome">
        <h2>Select Your Portal</h2>
        <p>Choose Admin or User to continue.</p>
    </div>

    <div class="cards">
        <div class="card">
            <div class="icon">👨‍💼</div>
            <h3>Admin Portal</h3>
            <p>Manage patients, doctors and appointments.</p>
            <a class="btn" href="login.php">Admin Login</a>
        </div>

        <div class="card">
            <div class="icon">👤</div>
            <h3>User Portal</h3>
            <p>Register, login, view doctors and book appointments.</p>
            <a class="btn" href="user_login.php">User Login</a>
            <a class="btn secondary" href="register.php">New User? Register</a>
        </div>
    </div>
</div>

<div class="footer">
    Hospital Management System
</div>

</body>
</html>
