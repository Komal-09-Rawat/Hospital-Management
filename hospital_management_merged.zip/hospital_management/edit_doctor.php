<?php
include "db.php";

if (!isset($_GET["id"])) {
    die("Doctor ID not found");
}

$id = $_GET["id"];

$sql = "SELECT * FROM doctors WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Doctor not found");
}

$doctor = $result->fetch_assoc();

if (isset($_POST["update"])) {

    $name = $_POST["name"];
    $specialization = $_POST["specialization"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];

    $sql = "UPDATE doctors SET
            name = '$name',
            specialization = '$specialization',
            phone = '$phone',
            email = '$email'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: doctors.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>

    <title>Edit Doctor</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fb;
            padding: 40px;
        }

        h1 {
            text-align: center;
            color: #1f4e79;
        }

        form {
            width: 400px;
            margin: 30px auto;
            background-color: white;
            padding: 25px;
            border-radius: 10px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background-color: #1f4e79;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .back {
            display: block;
            width: 170px;
            margin: 20px auto;
            padding: 12px;
            text-align: center;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>

</head>

<body>

<h1>✏️ Edit Doctor</h1>

<form method="POST">

    <label>Doctor Name:</label>
    <input type="text" name="name"
           value="<?php echo $doctor['name']; ?>" required>

    <label>Specialization:</label>
    <input type="text" name="specialization"
           value="<?php echo $doctor['specialization']; ?>" required>

    <label>Phone:</label>
    <input type="text" name="phone"
           value="<?php echo $doctor['phone']; ?>" required>

    <label>Email:</label>
    <input type="email" name="email"
           value="<?php echo $doctor['email']; ?>" required>

    <button type="submit" name="update">Update Doctor</button>

</form>

<a class="back" href="doctors.php">⬅ Back to Doctors</a>

</body>
</html>